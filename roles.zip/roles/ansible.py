import os
import sys
os.system(" sudo apt update -y ")
os.system(" sudo apt install software-properties-common -y ")
os.system(" sudo apt-add-repository ppa:ansible/ansible -y ")
os.system(" sudo apt update -y ")
os.system(" sudo apt install ansible -y ")
os.system(" clear ")
os.system(" sudo ansible --version ")

